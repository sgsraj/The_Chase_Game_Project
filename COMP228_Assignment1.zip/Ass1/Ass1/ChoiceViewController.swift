//
//  ChoiceViewController.swift
//  Ass1
//
//  Created by Shivansh Raj on 29/10/2024.
//

import UIKit

class ChoiceViewController: UIViewController {
    
    @IBOutlet weak var choiceHeader: UILabel!
    
    var name: String = "Player"
    var selectedAmount: Int = 0
    var earnedScore: Int = 0
    /*
     Tapping on the Lower amount button sends the player to start from fourth position in the
     ladder for the amount £1000 in the game view controller
     */
    @IBAction func lowAmount(_ sender: Any) {
        selectedAmount = 1000
        performSegue(withIdentifier: "toGame", sender: 3)
    }
    /*
     Tapping on the Standard amount button sends the player to start from fifth position in the
     ladder for the amount £7000 in the game view controller
     */
    @IBAction func standardAmount(_ sender: Any) {
        selectedAmount = 7000
        performSegue(withIdentifier: "toGame", sender: 2)
    }
    /*
     Tapping on the Higher amount button sends the player to start from sixth position in the
     ladder for the amount £30000 in the game view controller
     */
    @IBAction func highAmount(_ sender: Any) {
        selectedAmount = 30000
        performSegue(withIdentifier: "toGame", sender: 1)
    }
    /*
     This prepare function helps to transition the name and score forward to the game view
     controller so that the name and score of the player can be displayed in the high score table
     of the high score view controller
     */
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "toGame" {
            let destinationVC = segue.destination as? GameViewController
            if let startPosition = sender as? Int {
                destinationVC?.initialPosition = startPosition
            }
            destinationVC?.name = name
            destinationVC?.selectedAmount = selectedAmount
            destinationVC?.earnedScore = earnedScore
            // Do any additional setup after loading the view.
        }
    }
}
