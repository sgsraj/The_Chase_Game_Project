//
//  ResultViewController.swift
//  Ass1
//
//  Created by Shivansh Raj on 04/11/2024.
//

import UIKit

class ResultViewController: UIViewController {
    
    @IBOutlet weak var resultHeader: UILabel!
    
    @IBOutlet weak var resultLabel: UILabel!
    
    var winner: String?
    var name: String = "Player"
    var earnedScore: Int = 0
    
    @IBOutlet weak var restartGame: UIButton!
    /*
     Tapping on the Restart game button takes the player back to the default view controller to
     restart the game when the player gets defeated by the chaser
     */
    @IBAction func restartGame(_ sender: Any) {
        performSegue(withIdentifier: "toView", sender: nil)
    }
    /*
     Tapping on this button exits the player from the game and displays a thank you message
     */
    @IBOutlet weak var endGamebutton: UIButton!
    @IBAction func endGame(_ sender: Any) {
        performSegue(withIdentifier: "toEndGame", sender: nil)
    }
    @IBOutlet weak var playAgain: UIButton!
    /*
      Tapping on the Play again button sends the player to confirm the amount choice again in
      the choice view controller
     */
    @IBAction func playAgain(_ sender: Any) {
        performSegue(withIdentifier: "toChoice", sender: nil)
    }
     /*
     Tapping on the View high score button sends the player to the view the high scores in the
     high score view controller
     */
    @IBAction func viewHighScore(_ sender: Any) {
        performSegue(withIdentifier: "toHighScore", sender: nil)
    }
    // Saves the high score of the player in the high score table
    func saveHighScore(name: String, score: Int) {
        var highScores = UserDefaults.standard.array(forKey: "highScores") as? [[String: Any]] ?? []
        let newScore = ["name": name, "score": score] as [String : Any]
        highScores.append(newScore)
        UserDefaults.standard.set(highScores, forKey: "highScores")
        
        // This saves the recent player's name and score for highlighting purpose
        UserDefaults.standard.set(name, forKey: "recentHighScoreName")
        UserDefaults.standard.set(score, forKey: "recentHighScoreValue")
    }
    
    /*
     The prepare function helps to transition the name and score of the player back to the
     choice view controller
     */
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "toChoice" {
            let choiceVC = segue.destination as? ChoiceViewController
            choiceVC?.name = name
            choiceVC?.earnedScore = earnedScore
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        /*
         If the player wins then the following text is displayed in the result view controller
         and the restart game button remains disabled while the play again button is still enabled
         as the player has not yet lost
         */
        if let winner = winner {
            if winner == "Player" {
                resultLabel.text = "Congratulations! You Win!"
                playAgain.isEnabled = true
                restartGame.isEnabled = false
                endGamebutton.isEnabled = false
            }
            /*
             If the player is caught by the chaser then the following message gets displayed
             in the result view controller and the play again button is disabled this time because
             the player lost and so the player only has the option of restarting the game from
             the beginning
             */
            else {
                resultLabel.text = "Oops! You have been caught by the chaser"
                playAgain.isEnabled = false
                restartGame.isEnabled = true
                endGamebutton.isEnabled = true
                
                // This saves the final score to the high scores array
                saveHighScore(name: name, score: earnedScore)
                
                // This resets the total score in UserDefaults for future games
                UserDefaults.standard.set(0, forKey: "totalScore")
            }
        }
    }
}
