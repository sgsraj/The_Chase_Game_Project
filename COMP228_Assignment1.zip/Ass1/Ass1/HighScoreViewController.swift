//
//  HighScoreViewController.swift
//  Ass1
//
//  Created by Shivansh Raj on 29/10/2024.
//

import UIKit

class HighScoreViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    @IBAction func goBackButton(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    @IBOutlet weak var highScoreHeader: UILabel!
    @IBOutlet weak var tableView: UITableView!
    
    var highScores: [[String: Any]] = []
    var recentHighScoreIndex: Int?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Fetches high scores from UserDefaults
        highScores = UserDefaults.standard.array(forKey: "highScores") as? [[String: Any]] ?? []
        let recentName = UserDefaults.standard.string(forKey: "recentHighScoreName")
        let recentScore = UserDefaults.standard.integer(forKey: "recentHighScoreValue")
        
        
        // Sorts the high scores in descending order by score
        highScores.sort { primaryScore, secondaryScore in
            let primaryValue = primaryScore["score"] as? Int ?? 0
            let secondaryValue = secondaryScore["score"] as? Int ?? 0
            return primaryValue > secondaryValue
        }
        
        // Updates recentHighScoreIndex to the new index of the newest high score after sorting
        if let recentName = recentName {
            recentHighScoreIndex = highScores.firstIndex
            { scoreRecord in (scoreRecord["name"] as? String == recentName) && (scoreRecord["score"] as? Int == recentScore)
            }
        }
    }
    // Counts the number of high scores present in the table
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return highScores.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "myCell", for: indexPath)
        
        let highScore = highScores[indexPath.row]
        let name = highScore["name"] as? String ?? ""
        let score = highScore["score"] as? Int ?? 0
        
        cell.textLabel?.text = "\(name): £\(score) "// displays the score and name in the cell
        if indexPath.row == recentHighScoreIndex {
            cell.backgroundColor = .systemBlue // Highlights the newest high score in blue
        }
        else {
            cell.backgroundColor = .systemTeal // Defaults color for other cells in teal
        }
        return cell
    }
}


