//
//  GameViewController.swift
//  Ass1
//
//  Created by Shivansh Raj on 29/10/2024.
//

import UIKit
import AVFoundation

class GameViewController: UIViewController {
    
    @IBOutlet weak var gameHeader: UILabel!
    @IBOutlet weak var questionLabel: UILabel!
    
    @IBOutlet weak var button1outlet: UIButton!
    @IBOutlet weak var button2outlet: UIButton!
    @IBOutlet weak var button3outlet: UIButton!
    
    // Ladder steps as UIView outlets
    @IBOutlet weak var step1: UIView!
    @IBOutlet weak var step2: UIView!
    @IBOutlet weak var step3: UIView!
    @IBOutlet weak var step4: UIView!
    @IBOutlet weak var step5: UIView!
    @IBOutlet weak var step6: UIView!
    @IBOutlet weak var step7: UIView!
    
    var questions: [QuestionItems] = []
    var activeQuestionIndex = 0
    var initialPosition: Int = 0
    var playerLocation = 0
    let chaserAccuracy: Float = 0.75
    var name: String = "Player"
    var selectedAmount: Int = 0
    var earnedScore: Int = 0
    var timer: Timer?
    var timerCount: Int = 0
    var activeStage: TimerStage = .waitForPlayerResponse
    var isGameEnded = false
    var chaserLocation: Int = -1 // -1 means chaser is off the ladder
    var hasChaserEnteredLadder: Bool = false // Track if chaser has entered the ladder
    /*
     This enumeration code block helps the timer to switch into the required state of the gameplay
     */
    enum TimerStage {
        case waitForPlayerResponse
        case displayResponse
        case showCorrectAnswer
        case nextQuestion
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Helps to load and shuffle questions
        if let quizData = getJSONQuestionData() {
            questions = quizData.questions.shuffled()
        }
        
        // Sets the player location to the initial position specified by ChoiceViewController
        playerLocation = initialPosition
        
        // Displays the first question and updates ladder to reflect the starting position
        displayQuestion()
        updateLadder()
    }
    
    
    // Displays the current question
    func displayQuestion() {
        guard !isGameEnded, activeQuestionIndex < questions.count else {
                    endGame()
                    return
                }
        
        /*
         This code block retrieves the questions and the options according to there index
         */
        let activeQuestion = questions[activeQuestionIndex]
        questionLabel.text = activeQuestion.question_text
        button1outlet.setTitle(activeQuestion.answers[0], for: .normal)
        button2outlet.setTitle(activeQuestion.answers[1], for: .normal)
        button3outlet.setTitle(activeQuestion.answers[2], for: .normal)
        resetAnswerButtons()
        startTimer(for: .waitForPlayerResponse)
        updateLadder()
    }
    /*
     This code block helps to reset the answer buttons back to teal color after the display
     of every question and enables the answer buttons for selection in each question
     */
    func resetAnswerButtons() {
        button1outlet.backgroundColor = .systemTeal
        button2outlet.backgroundColor = .systemTeal
        button3outlet.backgroundColor = .systemTeal
        button1outlet.isEnabled = true
        button2outlet.isEnabled = true
        button3outlet.isEnabled = true
    }
    /*
     This starts the timer operations
     */
    func startTimer(for stage: TimerStage) {
        guard !isGameEnded else { return }
           timer?.invalidate() // Stop any existing timer
           timerCount = 0
           activeStage = stage
           timer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(timerCycle), userInfo: nil, repeats: true)
       }
    
    @objc func timerCycle() {
            guard !isGameEnded else {
                timer?.invalidate()
                return
            }
            
            timerCount += 1
            /*
             In ths case the timer is started and waits for the response of the player for 15
             seconds also handles the case of time-out and invalidates the timer for this part
             and starts the timer for displaying responses
             */
            switch activeStage {
            case .waitForPlayerResponse:
                if timerCount >= 15 {
                    timer?.invalidate()
                    validateAnswer(selectedAnswerIndex: -1, button: nil)
                    startTimer(for: .displayResponse)
                }
            /*
             In this case the timer handles the case of displaying responses
             and then it invalidates the timer for this part and then starts the timer for
             displaying correct answers
             */
            case .displayResponse:
                if timerCount >= 3 {
                    timer?.invalidate()
                    indicateCorrectAnswer(correctIndex: questions[activeQuestionIndex].correct)
                    startTimer(for: .showCorrectAnswer)
                }
                /*
                 In this case the timer handles the case of showing correct answers to the
                 player and then invalidates the timer and then prepares for the display
                 of the next question
                 */
            case .showCorrectAnswer:
                if timerCount >= 2 {
                    timer?.invalidate()
                    activeQuestionIndex += 1
                    displayQuestion()
                }
                
            case .nextQuestion:
                break
            }
        }
        
    
    // Actions for each answer button
    @IBAction func answerButton1(_ sender: Any) {
        validateAnswer(selectedAnswerIndex: 1, button: button1outlet)
    }
    
    @IBAction func answerButton2(_ sender: Any) {
        validateAnswer(selectedAnswerIndex: 2, button: button2outlet)
    }
    
    @IBAction func answerButton3(_ sender: Any) {
        validateAnswer(selectedAnswerIndex: 3, button: button3outlet)
    }
    
    // Handle player's answer
    func validateAnswer(selectedAnswerIndex: Int, button: UIButton?) {
            timer?.invalidate() // Stops timer immediately upon answer selection
            
            let activeQuestion = questions[activeQuestionIndex]
            let isCorrect = selectedAnswerIndex == activeQuestion.correct
            
            // Highlights player's answer in orange, if selected
            button?.backgroundColor = .systemOrange
            //Disables the rest option buttons after the selection of one option out of three
            button1outlet.isEnabled = false
            button2outlet.isEnabled = false
            button3outlet.isEnabled = false
        
            // Updates player position if the answer is correct
            if isCorrect {
                    playerLocation += 1
                if playerLocation > 6{
                        timer?.invalidate()
                        endGame(winner: "Player")
                        return
                    }
                }
            
            // Display's Chaser's response immediately after player’s response
            displayChaserResponse(for: activeQuestion)
            
            // Starts timer for displaying responses
            startTimer(for: .displayResponse)
        }
    
    // Simulates and displays the Chaser's response
    func displayChaserResponse(for question: QuestionItems) {
            // Determine if the chaser should answer correctly based on accuracy
            let chaserAnsweredCorrectly = Float.random(in: 0...1) < chaserAccuracy
            let correctIndex = question.correct - 1 // Adjust for zero-based indexing

            // Determine the chaser's selected answer
            let chaserSelectedIndex: Int
            if chaserAnsweredCorrectly {
                chaserSelectedIndex = correctIndex // Chaser answers correctly
            } else {
                // Chaser answers incorrectly by picking from the remaining choices
                let incorrectOptions = [0, 1, 2].filter { index in index != correctIndex }
                chaserSelectedIndex = incorrectOptions.randomElement()!
            }
        // Highlights Chaser’s selected answer in yellow after the response made by the player
        let chaserButton = [button1outlet, button2outlet, button3outlet][chaserSelectedIndex]
        chaserButton?.backgroundColor =  .systemYellow
        
        // Moves Chaser down the ladder if correct
        if chaserAnsweredCorrectly {
                    if !hasChaserEnteredLadder {
                        // First correct answer places the chaser at the top of the ladder
                        chaserLocation = 0 // Assuming 0 is the top position of the ladder
                        hasChaserEnteredLadder = true
                    } else {
                        // Subsequent correct answers move the chaser down by one step
                        chaserLocation += 1
                    }
            if chaserLocation == playerLocation {
                        timer?.invalidate() // Stop the timer
                        endGame(winner: "Chaser") // End the game with the Chaser as the winner
                        return
                    }
                }
                
                // Update ladder view to reflect Chaser’s new position
                updateLadder()
            }
    // This code block helps to highlight the correct answer in green and incorrect in red
    func indicateCorrectAnswer(correctIndex: Int) {
        // Array of all answer buttons for easy access
        let answerButtons = [button1outlet, button2outlet, button3outlet]
        
        // Loops through each button and apply color based on correctness
        for (index, button) in answerButtons.enumerated() {
            if index == correctIndex - 1 { // `correctIndex - 1` because indices start from 0
                // Highlights the correct answer in green
                button?.backgroundColor = .systemGreen
            } else {
                // Sets incorrect answers to red
                button?.backgroundColor = .systemRed
            }
        }
    }
    func updateLadder() {
            let ladderSteps = [step1, step2, step3, step4, step5, step6, step7]
            
            // Resets all ladder steps to default color mint
            for step in ladderSteps {
                step?.backgroundColor = .systemMint
            }
            
            // Highlights player’s starting location in blue in the ladder
        if playerLocation < ladderSteps.count {
            ladderSteps[playerLocation]?.backgroundColor = .systemBlue
            }
            
            // Highlights chaser’s location in red in the ladder
        if hasChaserEnteredLadder && chaserLocation < ladderSteps.count{
            ladderSteps[chaserLocation]?.backgroundColor = .systemRed
                }
        }

    
    func endGame(winner: String? = nil) {
        guard !isGameEnded else { return }
        isGameEnded = true
        timer?.invalidate()
        if winner == "Player" {
            earnedScore += selectedAmount
            }
        performSegue(withIdentifier: "toResult", sender: winner)
    }
    /*
     This prepare function helps to transition the name and the score of the player
     forward to the result view controller so that the name and score can be displayed in 
     */
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
           if segue.identifier == "toResult" {
               let destinationVC = segue.destination as? ResultViewController
               destinationVC?.winner = sender as? String
               destinationVC?.name = name
               destinationVC?.earnedScore = earnedScore
           }
       }
}
