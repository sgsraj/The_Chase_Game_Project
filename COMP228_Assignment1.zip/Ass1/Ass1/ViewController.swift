//
//  ViewController.swift
//  Ass1
//
//  Created by Shivansh Raj on 29/10/2024.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var viewHeader: UILabel!
    @IBOutlet weak var inputName: UITextField!
    var name: String = "Player"
    var earnedScore: Int = 0
    /*
     The player first enter their name in the textfield present in the view controller and then
     taps on the start game button which takes the player to the choice view controller where the
     player selects the amount they want to play for
     */
    @IBAction func startGame(_ sender: Any) {
        name = inputName.text?.isEmpty == false ? inputName.text! : "Player"
                
        performSegue(withIdentifier: "toChoice", sender: nil)
    }
    /*
     Tapping on this view high score button sends the player to view the high score in the
     high score view controller if the player wishes to view the high score before
     starting the game
     */
    @IBAction func highScore(_ sender: Any) {
        performSegue(withIdentifier: "toHighScore", sender: nil)
    }
    /*
     This prepare function helps in the traansition of the name and score of the player
     forward to the choice view controller so that the player's high score can be displayed in
     the high score table present in the high score view controller
     */
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "toChoice" {
            let destinationVC = segue.destination as? ChoiceViewController
            destinationVC?.name = name // Pass player’s name
            destinationVC?.earnedScore = earnedScore
        }
    }
}

